#
# Cookbook Name:: build_cookbook
# Recipe:: functional
#
# Copyright (c) 2017 Raytheon, All Rights Reserved.
include_recipe 'delivery-truck::functional'

#
# Cookbook Name:: build_cookbook
# Recipe:: publish
#
# Copyright (c) 2017 Raytheon, All Rights Reserved.
include_recipe 'delivery-truck::publish'

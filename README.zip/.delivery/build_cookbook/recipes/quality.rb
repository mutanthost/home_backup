#
# Cookbook Name:: build_cookbook
# Recipe:: quality
#
# Copyright (c) 2017 Raytheon, All Rights Reserved.
include_recipe 'delivery-truck::quality'

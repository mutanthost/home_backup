name 'build_cookbook'
maintainer 'Raytheon'
maintainer_email 'matthew.huston-nr@raytheon.com'
license 'all_rights'
version '0.1.0'

depends 'delivery-truck'

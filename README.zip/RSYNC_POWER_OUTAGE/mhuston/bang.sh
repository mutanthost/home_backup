#!/bin/bash
# This will rsync your $HOME , add all to your local git repo, commit and push
# Copyleft 2017, Matt Huston
# All rights reserved, all wrongs reversed
rsync -avzh /home/mhuston /home/mhuston_home/RSYNC_POWER_OUTAGE/
sleep 10
REPO=/home/mhuston/mhuston_home
pushd $REPO
git add . && git commit -a -m "ran rsync" && git push -u origin master
popd
exit
